const mongoose = require('mongoose');

module.exports = {
    mongoURI: 'mongodb://localhost:27017'
};
