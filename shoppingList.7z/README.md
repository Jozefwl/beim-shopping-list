# beim-shopping-list
 Shopping list backend

npm install

then

npm start

to run
